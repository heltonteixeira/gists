const ToastNotification = {
  name: 'ToastNotification',
  template: `
    <transition name="toast">
      <div v-if="show" :class="['toast', \`toast-\${type}\`]" role="alert" aria-live="assertive" aria-atomic="true">
        {{ message }}
      </div>
    </transition>
  `,
  props: {
    message: {
      type: String,
      required: true
    },
    type: {
      type: String,
      default: 'info',
      validator: (value) => ['info', 'success', 'warning', 'error'].includes(value)
    },
    duration: {
      type: Number,
      default: 3000
    }
  },
  data() {
    return {
      show: false
    }
  },
  mounted() {
    this.showToast()
  },
  methods: {
    showToast() {
      this.show = true
      setTimeout(() => {
        this.show = false
      }, this.duration)
    }
  }
};

// Add the styles as a string to be injected into the document
const style = `
.toast {
  position: fixed;
  bottom: 20px;
  right: 20px;
  padding: 10px 20px;
  border-radius: 4px;
  font-weight: bold;
  z-index: 9999;
  max-width: 300px;
  word-wrap: break-word;
}

.toast-info {
  background-color: #2196F3;
  color: white;
}

.toast-success {
  background-color: #4CAF50;
  color: white;
}

.toast-warning {
  background-color: #FFC107;
  color: black;
}

.toast-error {
  background-color: #F44336;
  color: white;
}

.toast-enter-active, .toast-leave-active {
  transition: opacity 0.3s, transform 0.3s;
}

.toast-enter-from, .toast-leave-to {
  opacity: 0;
  transform: translateY(20px);
}
`;

// Inject the styles into the document
const styleElement = document.createElement('style');
styleElement.textContent = style;
document.head.appendChild(styleElement);