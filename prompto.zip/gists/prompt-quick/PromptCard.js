const PromptCard = {
  name: 'PromptCard',
  template: `
    <div class="prompt-card bg-white border border-gray-200 w-64 h-auto flex flex-col p-4">
      <h3 class="text-xl font-bold uppercase mb-2 text-black">
        {{ title }}
      </h3>
      <div class="flex-grow overflow-hidden mb-4">
        <p class="text-sm text-gray-700 leading-tight">
          {{ content }}
        </p>
      </div>
      <div class="h-1 bg-red-500 w-1/3 mb-3"></div>
      <div class="flex justify-between items-center text-xs text-gray-500">
        <div class="flex space-x-3">
          <span class="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-1"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
            {{ views }}
          </span>
          <span class="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-1"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
            {{ likes }}
          </span>
          <span class="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-1"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
            {{ comments }}
          </span>
        </div>
        <span>{{ date }}</span>
      </div>
    </div>
  `,
  props: {
    title: {
      type: String,
      required: true
    },
    content: {
      type: String,
      required: true
    },
    views: {
      type: Number,
      default: 0
    },
    likes: {
      type: Number,
      default: 0
    },
    comments: {
      type: Number,
      default: 0
    },
    date: {
      type: String,
      required: true
    }
  }
};

// Make sure the component is available globally
window.PromptCard = PromptCard;