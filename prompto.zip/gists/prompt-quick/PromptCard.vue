<template>
  <div class="bg-white border border-gray-200 w-64 h-auto flex flex-col p-4">
    <h3 class="text-xl font-bold uppercase mb-2 text-black">
      {{ title }}
    </h3>
    <div class="flex-grow overflow-hidden mb-4">
      <p class="text-sm text-gray-700 leading-tight">
        {{ content }}
      </p>
    </div>
    <div class="h-1 bg-red-500 w-1/3 mb-3"></div>
    <div class="flex justify-between items-center text-xs text-gray-500">
      <div class="flex space-x-3">
        <span class="flex items-center">
          <Eye class="mr-1" :size="14" /> {{ views }}
        </span>
        <span class="flex items-center">
          <Heart class="mr-1" :size="14" /> {{ likes }}
        </span>
        <span class="flex items-center">
          <MessageSquare class="mr-1" :size="14" /> {{ comments }}
        </span>
      </div>
      <span>{{ date }}</span>
    </div>
  </div>
</template>

<script>
import { Eye, Heart, MessageSquare } from 'lucide-vue-next';

export default {
  name: 'PromptCard',
  components: {
    Eye,
    Heart,
    MessageSquare
  },
  props: {
    title: {
      type: String,
      required: true
    },
    content: {
      type: String,
      required: true
    },
    views: {
      type: Number,
      default: 0
    },
    likes: {
      type: Number,
      default: 0
    },
    comments: {
      type: Number,
      default: 0
    },
    date: {
      type: String,
      required: true
    }
  }
}
</script>

<style scoped>
/* Add any component-specific styles here */
</style>