const app = Vue.createApp({
    components: {
        PromptCard: window.PromptCard,
        ToastNotification
    },
    data() {
        return {
            prompts: [],
            newPrompt: {
                title: '',
                content: ''
            },
            editingPrompt: null,
            selectedPrompt: null,
            showMenu: false,
            toast: {
                message: '',
                type: 'info',
                show: false
            }
        }
    },
    computed: {
        hasPrompts() {
            console.log('hasPrompts computed property called, prompts length:', this.prompts.length);
            return this.prompts.length > 0;
        }
    },
    methods: {
        addPrompt() {
            if (this.newPrompt.title && this.newPrompt.content) {
                this.prompts.push({
                    id: uuid.v4(),
                    title: this.newPrompt.title,
                    content: this.newPrompt.content,
                    views: 0,
                    likes: 0,
                    comments: 0,
                    date: new Date().toISOString().split('T')[0]
                });
                this.resetNewPrompt();
                this.savePrompts();
                this.showToast('Prompt added successfully', 'success');
            }
        },
        resetNewPrompt() {
            this.newPrompt.title = '';
            this.newPrompt.content = '';
        },
        deletePrompt(prompt) {
            const index = this.prompts.findIndex(p => p.id === prompt.id);
            if (index !== -1) {
                this.prompts.splice(index, 1);
                this.savePrompts();
                this.showToast('Prompt deleted', 'info');
            }
            this.closeModal();
        },
        async copyPrompt(prompt) {
            try {
                await navigator.clipboard.writeText(prompt.content);
                this.showToast('Prompt copied to clipboard!', 'success');
            } catch (err) {
                console.error('Failed to copy prompt:', err);
                this.showToast('Failed to copy prompt', 'error');
            }
            this.closeMenu();
        },
        forkPrompt(prompt) {
            this.newPrompt.title = `${prompt.title} (Fork)`;
            this.newPrompt.content = prompt.content;
            this.closeModal();
            this.showToast('Prompt forked. Edit and save the new prompt.', 'info');
        },
        editPrompt(prompt) {
            this.editingPrompt = { ...prompt };
            this.closeMenu();
        },
        saveEditedPrompt() {
            const index = this.prompts.findIndex(p => p.id === this.editingPrompt.id);
            if (index !== -1) {
                this.prompts[index] = { ...this.editingPrompt };
                this.editingPrompt = null;
                this.selectedPrompt = null;
                this.savePrompts();
                this.showToast('Prompt updated successfully', 'success');
            }
        },
        cancelEditing() {
            this.editingPrompt = null;
            this.showToast('Editing cancelled', 'info');
        },
        formatContent(content) {
            return `<pre><code class="language-markdown">${this.escapeHtml(content)}</code></pre>`;
        },
        escapeHtml(unsafe) {
            return unsafe
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#x27;");
        },
        savePrompts() {
            localStorage.setItem('prompts', JSON.stringify(this.prompts));
        },
        loadPrompts() {
            const savedPrompts = localStorage.getItem('prompts');
            if (savedPrompts) {
                this.prompts = JSON.parse(savedPrompts);
                console.log('Loaded prompts:', this.prompts);
            } else {
                console.log('No saved prompts found in localStorage');
            }
        },
        showAbout() {
            this.showToast('This is a minimalist prompt management app designed with Swiss web style principles.', 'info');
        },
        showContact() {
            this.showToast('Contact: example@email.com', 'info');
        },
        toggleMenu(event) {
            if (this.showMenu) {
                this.closeMenu();
            } else {
                this.openMenu(event);
            }
        },
        openMenu(event) {
            this.showMenu = true;
            this.$nextTick(() => {
                this.positionMenu(event);
                document.addEventListener('click', this.handleOutsideClick);
            });
        },
        closeMenu() {
            this.showMenu = false;
            document.removeEventListener('click', this.handleOutsideClick);
            this.$refs.menuButton.blur();
        },
        handleOutsideClick(event) {
            if (this.$refs.actionMenu && !this.$refs.actionMenu.contains(event.target) && !this.$refs.menuButton.contains(event.target)) {
                this.closeMenu();
            }
        },
        positionMenu(event) {
            const menuButton = event.target;
            const actionMenu = this.$refs.actionMenu;
            
            if (menuButton && actionMenu) {
                const rect = menuButton.getBoundingClientRect();
                actionMenu.style.position = 'fixed';
                actionMenu.style.top = `${rect.bottom + window.scrollY}px`;
                actionMenu.style.left = `${rect.left}px`;
            }
        },
        openModal(prompt) {
            this.selectedPrompt = prompt;
            this.closeMenu();
        },
        closeModal() {
            this.selectedPrompt = null;
            this.closeMenu();
        },
        showToast(message, type = 'info') {
            this.toast.message = message;
            this.toast.type = type;
            this.toast.show = true;
        },
        handleKeydown(event) {
            if (event.key === 'Escape') {
                if (this.editingPrompt) {
                    this.cancelEditing();
                } else if (this.selectedPrompt) {
                    this.closeModal();
                } else if (this.showMenu) {
                    this.closeMenu();
                }
            }
        }
    },
    mounted() {
        this.loadPrompts();
        console.log('App mounted, prompts:', this.prompts);
        window.addEventListener('resize', this.positionMenu);
        window.addEventListener('keydown', this.handleKeydown);
    },
    beforeUnmount() {
        window.removeEventListener('resize', this.positionMenu);
        window.removeEventListener('keydown', this.handleKeydown);
        document.removeEventListener('click', this.handleOutsideClick);
    },
    updated() {
        this.$nextTick(() => {
            Prism.highlightAll();
        });
    }
});

const mountedApp = app.mount('#app');
console.log('Vue app instance:', mountedApp);
console.log('PromptCard component:', mountedApp.$options.components.PromptCard);
