<template>
    <div>
        <h2>{{ title }}</h2>
        <p>Count: {{ count }}</p>
        <button @click="increment">Increment</button>
        <button @click="decrement">Decrement</button>
        <button @click="reset">Reset</button>
    </div>
</template>

<script>
export default {
    name: 'MyCounter',
    data () {
        return {
            title: 'Vue.js Counter',
            steps: 5,
            count: 0
        }
    },
    methods: {
        increment () {
            this.count+=this.steps
        },
        decrement () {
            this.count-=this.steps
        },
        reset () {
            this.count = 0
        }
    }
}
</script>