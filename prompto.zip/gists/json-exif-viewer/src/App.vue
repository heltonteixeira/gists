<template>
  <div id="app">
    <MyCounter/>
  </div>
</template>

<script>
import MyCounter from './components/MyCounter.vue'

export default {
  name: 'App',
  components: {
    MyCounter
  }
}
</script>