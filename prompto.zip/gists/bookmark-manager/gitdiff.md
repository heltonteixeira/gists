diff --git a/index.html b/index.html
index e503ef4..4129359 100644
--- a/index.html
+++ b/index.html
@@ -6,7 +6,7 @@
     <title>Minimalist Bookmark Manager</title>
     <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
-    <link rel="stylesheet" href="style.css">
+    <link rel="stylesheet" href="./style.css">
 </head>
 <body>
     <div class="container">
@@ -26,11 +26,18 @@
     <div id="modal" class="modal">
         <div class="modal-content">
             <h2 id="modalTitle">Add Bookmark</h2>
-            <form id="bookmarkForm">
-                <input type="text" id="url" placeholder="URL" required>
-                <input type="text" id="title" placeholder="Site Name">
-                <input type="text" id="folder" placeholder="Folder">
-                <input type="text" id="tags" placeholder="Tags (comma-separated)">
+            <form id="bookmarkForm" autocomplete="off">
+                <input type="text" id="url" placeholder="URL" required autocomplete="off">
+                <input type="text" id="title" placeholder="Site Name" autocomplete="off">
+                <div class="input-container">
+                    <input type="text" id="folder" placeholder="Folder" autocomplete="off">
+                    <div id="folderSuggestions" class="suggestions"></div>
+                </div>
+                <div class="input-container">
+                    <input type="text" id="tags" placeholder="Tags (comma-separated)" autocomplete="off">
+                    <div id="tagSuggestions" class="suggestions"></div>
+                </div>
+                <div id="selectedTags" class="selected-tags"></div>
                 <div class="form-actions">
                     <button type="submit" class="btn-primary">Save</button>
                     <button type="button" id="cancelButton" class="btn-secondary">Cancel</button>
@@ -40,6 +47,6 @@
     </div>
 
     <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.4.0/axios.min.js"></script>
-    <script src="script.js"></script>
+    <script src="./script.js"></script>
 </body>
 </html>
\ No newline at end of file
diff --git a/script.js b/script.js
index ef40822..9152520 100644
--- a/script.js
+++ b/script.js
@@ -1,3 +1,51 @@
+// Modules
+const TagManager = (function() {
+    let tags = new Set();
+
+    function addTag(tag) {
+        tags.add(tag);
+    }
+
+    function removeTag(tag) {
+        tags.delete(tag);
+    }
+
+    function getAllTags() {
+        return Array.from(tags);
+    }
+
+    function getSuggestions(input) {
+        const inputLower = input.toLowerCase();
+        return getAllTags().filter(tag => tag.toLowerCase().includes(inputLower));
+    }
+
+    return { addTag, removeTag, getAllTags, getSuggestions };
+})();
+
+const FolderManager = (function() {
+    let folders = new Set();
+
+    function addFolder(folder) {
+        folders.add(folder);
+    }
+
+    function removeFolder(folder) {
+        folders.delete(folder);
+    }
+
+    function getAllFolders() {
+        return Array.from(folders);
+    }
+
+    function getSuggestions(input) {
+        const inputLower = input.toLowerCase();
+        return getAllFolders().filter(folder => folder.toLowerCase().includes(inputLower));
+    }
+
+    return { addFolder, removeFolder, getAllFolders, getSuggestions };
+})();
+
+// Main application
 let bookmarks = [];
 let editingIndex = -1;
 
@@ -5,24 +53,42 @@ document.addEventListener('DOMContentLoaded', () => {
     loadBookmarks();
     displayBookmarks();
     updateFolderFilter();
+    setupEventListeners();
+});
 
+function setupEventListeners() {
     document.getElementById('addBookmark').addEventListener('click', () => openModal());
     document.getElementById('bookmarkForm').addEventListener('submit', saveBookmark);
     document.getElementById('cancelButton').addEventListener('click', closeModal);
     document.getElementById('searchInput').addEventListener('input', filterBookmarks);
     document.getElementById('folderFilter').addEventListener('change', filterBookmarks);
-});
+    setupTagsAndFolders();
+}
 
-function loadBookmarks() {
-    const savedBookmarks = localStorage.getItem('bookmarks');
-    if (savedBookmarks) {
-        bookmarks = JSON.parse(savedBookmarks);
+async function loadBookmarks() {
+    try {
+        const savedBookmarks = localStorage.getItem('bookmarks');
+        if (savedBookmarks) {
+            bookmarks = JSON.parse(savedBookmarks);
+            bookmarks.forEach(bookmark => {
+                bookmark.tags.forEach(tag => TagManager.addTag(tag));
+                if (bookmark.folder) FolderManager.addFolder(bookmark.folder);
+            });
+        }
+    } catch (error) {
+        console.error('Error loading bookmarks:', error);
+        showNotification('Error loading bookmarks. Please try again.', 'error');
     }
 }
 
 function saveBookmarksToStorage() {
-    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
-    updateFolderFilter();
+    try {
+        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
+        updateFolderFilter();
+    } catch (error) {
+        console.error('Error saving bookmarks:', error);
+        showNotification('Error saving bookmarks. Please try again.', 'error');
+    }
 }
 
 function displayBookmarks(filteredBookmarks = bookmarks) {
@@ -30,42 +96,58 @@ function displayBookmarks(filteredBookmarks = bookmarks) {
     bookmarkList.innerHTML = '';
 
     filteredBookmarks.forEach((bookmark, index) => {
-        const bookmarkElement = document.createElement('div');
-        bookmarkElement.classList.add('bookmark');
+        const bookmarkElement = createBookmarkElement(bookmark, index);
+        bookmarkList.appendChild(bookmarkElement);
 
-        const infoElement = document.createElement('div');
-        infoElement.classList.add('bookmark-info');
+        if (!bookmark.title || bookmark.title === cleanUpUrl(bookmark.url)) {
+            fetchSiteTitle(bookmark.url).then(fetchedTitle => {
+                bookmark.title = fetchedTitle;
+                bookmarkElement.querySelector('.bookmark-title').textContent = fetchedTitle;
+                saveBookmarksToStorage();
+            });
+        }
+    });
+}
 
-        const titleElement = document.createElement('h3');
-        titleElement.classList.add('bookmark-title');
-        titleElement.textContent = bookmark.title;
+function createBookmarkElement(bookmark, index) {
+    const bookmarkElement = document.createElement('div');
+    bookmarkElement.classList.add('bookmark');
 
-        const detailsElement = document.createElement('p');
-        detailsElement.classList.add('bookmark-details');
-        detailsElement.textContent = `${bookmark.folder} | ${bookmark.tags.join(', ')} | Views: ${bookmark.views}`;
+    const infoElement = document.createElement('div');
+    infoElement.classList.add('bookmark-info');
 
-        infoElement.appendChild(titleElement);
-        infoElement.appendChild(detailsElement);
+    const titleElement = document.createElement('h3');
+    titleElement.classList.add('bookmark-title');
+    titleElement.textContent = bookmark.title;
+    titleElement.dataset.index = index;
 
-        const actionsElement = document.createElement('div');
-        actionsElement.classList.add('bookmark-actions');
+    const detailsElement = document.createElement('p');
+    detailsElement.classList.add('bookmark-details');
+    detailsElement.textContent = `${bookmark.folder} | ${bookmark.tags.join(', ')} | Views: ${bookmark.views}`;
 
-        const editIcon = document.createElement('i');
-        editIcon.classList.add('fas', 'fa-edit', 'edit-icon');
-        editIcon.addEventListener('click', () => openModal(index));
+    infoElement.appendChild(titleElement);
+    infoElement.appendChild(detailsElement);
 
-        const deleteIcon = document.createElement('i');
-        deleteIcon.classList.add('fas', 'fa-trash-alt', 'delete-icon');
-        deleteIcon.addEventListener('click', () => deleteBookmark(index));
+    const actionsElement = document.createElement('div');
+    actionsElement.classList.add('bookmark-actions');
 
-        actionsElement.appendChild(editIcon);
-        actionsElement.appendChild(deleteIcon);
+    const editIcon = createActionIcon('fas fa-edit edit-icon', () => openModal(index));
+    const deleteIcon = createActionIcon('fas fa-trash-alt delete-icon', () => deleteBookmark(index));
 
-        bookmarkElement.appendChild(infoElement);
-        bookmarkElement.appendChild(actionsElement);
+    actionsElement.appendChild(editIcon);
+    actionsElement.appendChild(deleteIcon);
 
-        bookmarkList.appendChild(bookmarkElement);
-    });
+    bookmarkElement.appendChild(infoElement);
+    bookmarkElement.appendChild(actionsElement);
+
+    return bookmarkElement;
+}
+
+function createActionIcon(classes, clickHandler) {
+    const icon = document.createElement('i');
+    icon.className = classes;
+    icon.addEventListener('click', clickHandler);
+    return icon;
 }
 
 function openModal(index = -1) {
@@ -73,17 +155,20 @@ function openModal(index = -1) {
     const modal = document.getElementById('modal');
     const form = document.getElementById('bookmarkForm');
     const modalTitle = document.getElementById('modalTitle');
+    const selectedTagsContainer = document.getElementById('selectedTags');
+
+    form.reset();
+    selectedTagsContainer.innerHTML = '';
 
     if (index === -1) {
         modalTitle.textContent = 'Add Bookmark';
-        form.reset();
     } else {
         modalTitle.textContent = 'Edit Bookmark';
         const bookmark = bookmarks[index];
         document.getElementById('url').value = bookmark.url;
         document.getElementById('title').value = bookmark.title;
         document.getElementById('folder').value = bookmark.folder;
-        document.getElementById('tags').value = bookmark.tags.join(', ');
+        bookmark.tags.forEach(tag => addSelectedTag(tag));
     }
 
     modal.style.display = 'block';
@@ -100,7 +185,7 @@ async function saveBookmark(event) {
     const url = sanitizeUrl(document.getElementById('url').value);
     const title = document.getElementById('title').value;
     const folder = document.getElementById('folder').value;
-    const tags = document.getElementById('tags').value.split(',').map(tag => tag.trim());
+    const selectedTags = Array.from(document.getElementById('selectedTags').children).map(tag => tag.querySelector('.tag-text').textContent.trim());
 
     try {
         let fetchedTitle = title;
@@ -112,7 +197,7 @@ async function saveBookmark(event) {
             url,
             title: fetchedTitle,
             folder,
-            tags,
+            tags: selectedTags,
             createdAt: new Date().toISOString(),
             modifiedAt: new Date().toISOString(),
             views: 0
@@ -121,20 +206,26 @@ async function saveBookmark(event) {
         if (editingIndex === -1) {
             bookmarks.push(bookmark);
         } else {
-            bookmarks[editingIndex] = {
-                ...bookmarks[editingIndex],
-                ...bookmark,
-                createdAt: bookmarks[editingIndex].createdAt,
-                views: bookmarks[editingIndex].views
-            };
+            bookmark.createdAt = bookmarks[editingIndex].createdAt;
+            bookmark.views = bookmarks[editingIndex].views;
+            bookmarks[editingIndex] = bookmark;
+        }
+
+        // Add tags to TagManager
+        selectedTags.forEach(tag => TagManager.addTag(tag));
+
+        // Add folder to FolderManager
+        if (folder) {
+            FolderManager.addFolder(folder);
         }
 
         saveBookmarksToStorage();
         displayBookmarks();
         closeModal();
+        showNotification('Bookmark saved successfully!', 'success');
     } catch (error) {
         console.error('Error saving bookmark:', error);
-        alert('Error saving bookmark. Please try again.');
+        showNotification('Error saving bookmark. Please try again.', 'error');
     }
 }
 
@@ -147,21 +238,151 @@ function sanitizeUrl(url) {
 
 async function fetchSiteTitle(url) {
     try {
-        const response = await axios.get(`https://cors-anywhere.herokuapp.com/${url}`);
-        const html = response.data;
+        const proxyUrl = 'https://cors-anywhere.herokuapp.com/' + url;
+        const response = await fetch(proxyUrl);
+        const html = await response.text();
         const match = html.match(/<title>(.*?)<\/title>/i);
-        return match ? match[1] : url;
+        return match ? match[1] : cleanUpUrl(url);
     } catch (error) {
         console.error('Error fetching site title:', error);
-        return url;
+        return cleanUpUrl(url);
     }
 }
 
+function cleanUpUrl(url) {
+    let cleanUrl = url.replace(/(https?:\/\/)?(www\.)?/, '');
+    cleanUrl = cleanUrl.split('/')[0];
+    return cleanUrl.split('.').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
+}
+
+function setupTagsAndFolders() {
+    setupInputSuggestions('tags', TagManager.getSuggestions, addSelectedTag);
+    setupInputSuggestions('folder', FolderManager.getSuggestions, (folder) => {
+        document.getElementById('folder').value = folder;
+        document.getElementById('folderSuggestions').innerHTML = '';
+    });
+
+    document.addEventListener('click', (event) => {
+        if (!event.target.closest('#tagSuggestions')) {
+            document.getElementById('tagSuggestions').innerHTML = '';
+        }
+        if (!event.target.closest('#folderSuggestions')) {
+            document.getElementById('folderSuggestions').innerHTML = '';
+        }
+    });
+
+    // Prevent form submission on Enter key press in folder and tags inputs
+    ['folder', 'tags'].forEach(id => {
+        document.getElementById(id).addEventListener('keydown', (event) => {
+            if (event.key === 'Enter') {
+                event.preventDefault();
+            }
+        });
+    });
+}
+
+function setupInputSuggestions(inputId, getSuggestions, onSelect) {
+    const input = document.getElementById(inputId);
+    const suggestionsContainer = document.getElementById(`${inputId}Suggestions`);
+    let selectedIndex = -1;
+
+    input.addEventListener('input', () => {
+        const inputValue = input.value.trim().toLowerCase();
+        if (inputValue) {
+            const suggestions = getSuggestions(inputValue);
+            displaySuggestions(suggestionsContainer, suggestions, onSelect);
+        } else {
+            suggestionsContainer.innerHTML = '';
+        }
+        selectedIndex = -1;
+    });
+
+    input.addEventListener('keydown', (event) => {
+        const suggestions = suggestionsContainer.children;
+        if (suggestions.length === 0) return;
+
+        if (event.key === 'ArrowDown') {
+            event.preventDefault();
+            selectedIndex = (selectedIndex + 1) % suggestions.length;
+            updateSelectedSuggestion(suggestions, selectedIndex);
+        } else if (event.key === 'ArrowUp') {
+            event.preventDefault();
+            selectedIndex = (selectedIndex - 1 + suggestions.length) % suggestions.length;
+            updateSelectedSuggestion(suggestions, selectedIndex);
+        } else if (event.key === 'Enter' && selectedIndex !== -1) {
+            event.preventDefault();
+            onSelect(suggestions[selectedIndex].textContent);
+            suggestionsContainer.innerHTML = '';
+            selectedIndex = -1;
+        }
+    });
+
+    // Handle tag input with comma separator
+    if (inputId === 'tags') {
+        input.addEventListener('keydown', (event) => {
+            if (event.key === ',' || event.key === 'Enter') {
+                event.preventDefault();
+                const tagValue = input.value.trim();
+                if (tagValue) {
+                    addSelectedTag(tagValue);
+                    input.value = '';
+                }
+            }
+        });
+    }
+}
+
+function updateSelectedSuggestion(suggestions, selectedIndex) {
+    Array.from(suggestions).forEach((suggestion, index) => {
+        suggestion.classList.toggle('selected', index === selectedIndex);
+    });
+}
+
+function displaySuggestions(container, items, onSelect) {
+    container.innerHTML = '';
+    items.forEach(item => {
+        const suggestionElement = document.createElement('div');
+        suggestionElement.classList.add('suggestion');
+        suggestionElement.textContent = item;
+        suggestionElement.addEventListener('click', () => {
+            onSelect(item);
+            container.innerHTML = '';
+        });
+        container.appendChild(suggestionElement);
+    });
+}
+
+function addSelectedTag(tag) {
+    const selectedTagsContainer = document.getElementById('selectedTags');
+    const tagElement = document.createElement('span');
+    tagElement.classList.add('selected-tag');
+
+    const tagText = document.createElement('span');
+    tagText.classList.add('tag-text');
+    tagText.textContent = tag;
+
+    const removeButton = document.createElement('span');
+    removeButton.classList.add('remove-tag');
+    removeButton.textContent = '×';
+    removeButton.addEventListener('click', () => {
+        selectedTagsContainer.removeChild(tagElement);
+    });
+
+    tagElement.appendChild(tagText);
+    tagElement.appendChild(removeButton);
+    selectedTagsContainer.appendChild(tagElement);
+
+    document.getElementById('tags').value = '';
+    document.getElementById('tagSuggestions').innerHTML = '';
+    TagManager.addTag(tag);
+}
+
 function deleteBookmark(index) {
     if (confirm('Are you sure you want to delete this bookmark?')) {
         bookmarks.splice(index, 1);
         saveBookmarksToStorage();
         displayBookmarks();
+        showNotification('Bookmark deleted successfully!', 'success');
     }
 }
 
@@ -182,10 +403,10 @@ function filterBookmarks() {
 
 function updateFolderFilter() {
     const folderFilter = document.getElementById('folderFilter');
-    const folders = new Set(bookmarks.map(bookmark => bookmark.folder));
+    const uniqueFolders = FolderManager.getAllFolders();
     
     folderFilter.innerHTML = '<option value="">All Folders</option>';
-    folders.forEach(folder => {
+    uniqueFolders.forEach(folder => {
         if (folder) {
             const option = document.createElement('option');
             option.value = folder;
@@ -193,4 +414,16 @@ function updateFolderFilter() {
             folderFilter.appendChild(option);
         }
     });
+}
+
+function showNotification(message, type) {
+    const notification = document.createElement('div');
+    notification.classList.add('notification', type);
+    notification.textContent = message;
+
+    document.body.appendChild(notification);
+
+    setTimeout(() => {
+        notification.remove();
+    }, 3000);
 }
\ No newline at end of file
diff --git a/style.css b/style.css
index cec1733..234cc37 100644
--- a/style.css
+++ b/style.css
@@ -1,156 +1,291 @@
 :root {
-   --primary-color: #3498db;
-   --secondary-color: #2c3e50;
-   --background-color: #f8f9fa;
-   --text-color: #333;
-   --border-color: #e0e0e0;
+    --primary-color: #3498db;
+    --secondary-color: #2c3e50;
+    --background-color: #f8f9fa;
+    --text-color: #333;
+    --border-color: #e0e0e0;
+    --tag-bg-color: #e1f0fb;
+    --tag-text-color: #2980b9;
+    --success-color: #2ecc71;
+    --error-color: #e74c3c;
 }
 
 body {
-   font-family: 'Inter', sans-serif;
-   line-height: 1.6;
-   color: var(--text-color);
-   margin: 0;
-   padding: 0;
-   background-color: var(--background-color);
+    font-family: 'Inter', sans-serif;
+    line-height: 1.6;
+    color: var(--text-color);
+    margin: 0;
+    padding: 0;
+    background-color: var(--background-color);
 }
 
 .container {
-   max-width: 800px;
-   margin: 0 auto;
-   padding: 20px;
+    max-width: 800px;
+    margin: 0 auto;
+    padding: 20px;
 }
 
 header {
-   display: flex;
-   justify-content: space-between;
-   align-items: center;
-   margin-bottom: 20px;
+    display: flex;
+    justify-content: space-between;
+    align-items: center;
+    margin-bottom: 20px;
+    flex-wrap: wrap;
 }
 
 h1 {
-   font-size: 24px;
-   font-weight: 600;
-   color: var(--secondary-color);
-   margin: 0;
+    font-size: 24px;
+    font-weight: 600;
+    color: var(--secondary-color);
+    margin: 0;
 }
 
 .btn-primary, .btn-secondary {
-   padding: 8px 16px;
-   border: none;
-   border-radius: 4px;
-   cursor: pointer;
-   font-size: 14px;
-   transition: background-color 0.3s;
+    padding: 8px 16px;
+    border: none;
+    border-radius: 4px;
+    cursor: pointer;
+    font-size: 14px;
+    transition: background-color 0.3s, transform 0.1s;
 }
 
 .btn-primary {
-   background-color: var(--primary-color);
-   color: white;
+    background-color: var(--primary-color);
+    color: white;
 }
 
 .btn-secondary {
-   background-color: #e0e0e0;
-   color: var(--text-color);
+    background-color: #e0e0e0;
+    color: var(--text-color);
+}
+
+.btn-primary:hover, .btn-secondary:hover {
+    transform: translateY(-1px);
 }
 
 .btn-primary:hover {
-   background-color: #2980b9;
+    background-color: #2980b9;
 }
 
 .btn-secondary:hover {
-   background-color: #d0d0d0;
+    background-color: #d0d0d0;
 }
 
 #filterContainer {
-   display: flex;
-   gap: 10px;
-   margin-bottom: 20px;
+    display: flex;
+    gap: 10px;
+    margin-bottom: 20px;
+    flex-wrap: wrap;
 }
 
 #searchInput, #folderFilter {
-   flex: 1;
-   padding: 8px;
-   border: 1px solid var(--border-color);
-   border-radius: 4px;
-   font-size: 14px;
+    flex: 1;
+    min-width: 200px;
+    padding: 8px;
+    border: 1px solid var(--border-color);
+    border-radius: 4px;
+    font-size: 14px;
 }
 
 .bookmark {
-   background: white;
-   padding: 12px;
-   margin-bottom: 10px;
-   border-radius: 4px;
-   box-shadow: 0 1px 3px rgba(0,0,0,0.1);
-   display: flex;
-   justify-content: space-between;
-   align-items: center;
+    background: white;
+    padding: 12px;
+    margin-bottom: 10px;
+    border-radius: 4px;
+    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
+    display: flex;
+    justify-content: space-between;
+    align-items: center;
+    flex-wrap: wrap;
+    transition: transform 0.2s, box-shadow 0.2s;
+}
+
+.bookmark:hover {
+    transform: translateY(-2px);
+    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
 }
 
 .bookmark-info {
-   flex-grow: 1;
+    flex-grow: 1;
+    min-width: 200px;
 }
 
 .bookmark-title {
-   font-weight: 600;
-   margin: 0 0 4px 0;
-   color: var(--secondary-color);
+    font-weight: 600;
+    margin: 0 0 4px 0;
+    color: var(--secondary-color);
 }
 
 .bookmark-details {
-   font-size: 12px;
-   color: #7f8c8d;
-   margin: 0;
+    font-size: 12px;
+    color: #7f8c8d;
+    margin: 0;
 }
 
 .bookmark-actions {
-   display: flex;
-   gap: 10px;
+    display: flex;
+    gap: 10px;
 }
 
 .edit-icon, .delete-icon {
-   cursor: pointer;
-   color: var(--primary-color);
-   font-size: 16px;
+    cursor: pointer;
+    color: var(--primary-color);
+    font-size: 16px;
+    transition: color 0.2s;
+}
+
+.edit-icon:hover, .delete-icon:hover {
+    color: var(--secondary-color);
 }
 
 .modal {
-   display: none;
-   position: fixed;
-   z-index: 1;
-   left: 0;
-   top: 0;
-   width: 100%;
-   height: 100%;
-   background-color: rgba(0,0,0,0.4);
+    display: none;
+    position: fixed;
+    z-index: 1;
+    left: 0;
+    top: 0;
+    width: 100%;
+    height: 100%;
+    background-color: rgba(0,0,0,0.4);
 }
 
 .modal-content {
-   background-color: white;
-   margin: 15% auto;
-   padding: 20px;
-   border-radius: 4px;
-   max-width: 400px;
-   width: 100%;
+    background-color: white;
+    margin: 15% auto;
+    padding: 20px;
+    border-radius: 4px;
+    max-width: 400px;
+    width: 100%;
+    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
 }
 
 .modal-content h2 {
-   margin-top: 0;
-   color: var(--secondary-color);
+    margin-top: 0;
+    color: var(--secondary-color);
 }
 
 .modal-content input[type="text"] {
-   width: 100%;
-   padding: 8px;
-   margin: 8px 0;
-   border: 1px solid var(--border-color);
-   border-radius: 4px;
-   font-size: 14px;
+    width: 100%;
+    padding: 8px;
+    margin: 8px 0;
+    border: 1px solid var(--border-color);
+    border-radius: 4px;
+    font-size: 14px;
 }
 
 .form-actions {
-   display: flex;
-   justify-content: flex-end;
-   gap: 10px;
-   margin-top: 16px;
+    display: flex;
+    justify-content: flex-end;
+    gap: 10px;
+    margin-top: 16px;
+}
+
+.input-container {
+    position: relative;
+    margin-bottom: 10px;
+}
+
+.suggestions {
+    position: absolute;
+    top: 100%;
+    left: 0;
+    right: 0;
+    background-color: white;
+    border: 1px solid var(--border-color);
+    border-top: none;
+    border-radius: 0 0 4px 4px;
+    max-height: 150px;
+    overflow-y: auto;
+    z-index: 1;
+}
+
+.suggestion {
+    padding: 8px;
+    cursor: pointer;
+    transition: background-color 0.2s;
+}
+
+.suggestion:hover, .suggestion.selected {
+    background-color: var(--tag-bg-color);
+}
+
+.selected-tags {
+    display: flex;
+    flex-wrap: wrap;
+    gap: 8px;
+    margin-top: 8px;
+    margin-bottom: 16px;
+}
+
+.selected-tag {
+    background-color: var(--tag-bg-color);
+    color: var(--tag-text-color);
+    padding: 4px 8px;
+    border-radius: 16px;
+    font-size: 14px;
+    display: flex;
+    align-items: center;
+}
+
+.remove-tag {
+    margin-left: 6px;
+    cursor: pointer;
+    font-weight: bold;
+}
+
+.notification {
+    position: fixed;
+    top: 20px;
+    right: 20px;
+    padding: 10px 20px;
+    border-radius: 4px;
+    color: white;
+    font-size: 14px;
+    opacity: 0;
+    transition: opacity 0.3s;
+    z-index: 1000;
+}
+
+.notification.success {
+    background-color: var(--success-color);
+}
+
+.notification.error {
+    background-color: var(--error-color);
+}
+
+.notification.show {
+    opacity: 1;
+}
+
+@media (max-width: 600px) {
+    .container {
+        padding: 10px;
+    }
+
+    header {
+        flex-direction: column;
+        align-items: flex-start;
+    }
+
+    h1 {
+        margin-bottom: 10px;
+    }
+
+    #filterContainer {
+        flex-direction: column;
+    }
+
+    #searchInput, #folderFilter {
+        width: 100%;
+    }
+
+    .bookmark {
+        flex-direction: column;
+        align-items: flex-start;
+    }
+
+    .bookmark-actions {
+        margin-top: 10px;
+    }
 }
\ No newline at end of file
