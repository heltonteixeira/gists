diff --git a/.gitignore b/.gitignore
index de9bf17..a4ac758 100644
--- a/.gitignore
+++ b/.gitignore
@@ -18,4 +18,9 @@ _site/
 Gemfile.lock
 
 # Specific ignor for Git Config file
-.gitconfig
\ No newline at end of file
+.gitconfig
+
+# Certificate Keys
+*.pem
+cert.pem
+key.pem
\ No newline at end of file
